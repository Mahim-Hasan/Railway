from django.contrib import admin
from .models import *

admin.site.register(Train)
admin.site.register(Start)
admin.site.register(End)
admin.site.register(Ticket)
# Register your models here.
